#import <Foundation/Foundation.h>
#import "SM_AFURLRequestSerialization.h"

@interface BinaryRequestSerializer : SM_AFHTTPRequestSerializer

+ (instancetype)serializer;

@end
